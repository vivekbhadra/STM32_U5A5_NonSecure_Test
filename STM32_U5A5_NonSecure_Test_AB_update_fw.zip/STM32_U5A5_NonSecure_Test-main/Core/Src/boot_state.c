#include "boot_state.h"
#include "stm32u5xx_hal.h"
#include <string.h>

const BootStateRecord_t *BootState_GetRecord(void)
{
    return (const BootStateRecord_t *)BOOT_STATE_ADDR;
}

int BootState_IsValidSlot(uint32_t slot)
{
    return (slot == BOOT_SLOT_A) || (slot == BOOT_SLOT_B);
}

uint32_t BootState_GetAddressForSlot(uint32_t slot)
{
    if (slot == BOOT_SLOT_A)
    {
        return ADDR_FLASH_SLOT_A;
    }

    if (slot == BOOT_SLOT_B)
    {
        return ADDR_FLASH_SLOT_B;
    }

    return 0U;
}

uint32_t BootState_GetSizeForSlot(uint32_t slot)
{
    if (slot == BOOT_SLOT_A)
    {
        return SIZE_FLASH_SLOT_A;
    }

    if (slot == BOOT_SLOT_B)
    {
        return SIZE_FLASH_SLOT_B;
    }

    return 0U;
}

uint32_t BootState_GetInactiveSlot(uint32_t current_slot)
{
    if (current_slot == BOOT_SLOT_A)
    {
        return BOOT_SLOT_B;
    }

    if (current_slot == BOOT_SLOT_B)
    {
        return BOOT_SLOT_A;
    }

    return BOOT_SLOT_NONE;
}

int BootState_IsUpdateImageSizeValid(uint32_t slot, uint32_t image_size)
{
    uint32_t slot_size = BootState_GetSizeForSlot(slot);

    if (slot_size == 0U)
    {
        return 0;
    }

    if (image_size == 0U)
    {
        return 0;
    }

    if (image_size > slot_size)
    {
        return 0;
    }

    return 1;
}

int BootState_IsValidRecord(const BootStateRecord_t *record)
{
    if (record == 0)
    {
        return 0;
    }

    if (record->magic != BOOT_STATE_RECORD_MAGIC)
    {
        return 0;
    }

    if (record->version != BOOT_STATE_RECORD_VERSION)
    {
        return 0;
    }

    if (!BootState_IsValidSlot(record->current_slot))
    {
        return 0;
    }

    if ((record->rollback_slot != BOOT_SLOT_NONE) &&
        !BootState_IsValidSlot(record->rollback_slot))
    {
        return 0;
    }

    switch ((BootStateValue_t)record->state)
    {
        case BOOT_STATE_CONFIRMED:
            return 1;

        case BOOT_STATE_UPDATE_PENDING:
        case BOOT_STATE_UPDATE_TRIAL:
            if (!BootState_IsValidSlot(record->update_slot))
            {
                return 0;
            }

            if (record->update_slot == record->current_slot)
            {
                return 0;
            }

            return BootState_IsUpdateImageSizeValid(record->update_slot,
                                                    record->update_size);

        case BOOT_STATE_ROLLBACK:
            return 1;

        default:
            return 0;
    }
}

int BootState_IsUpdatePending(const BootStateRecord_t *record)
{
    return BootState_IsValidRecord(record) &&
           (record->state == BOOT_STATE_UPDATE_PENDING);
}

int BootState_IsUpdateTrial(const BootStateRecord_t *record)
{
    return BootState_IsValidRecord(record) &&
           (record->state == BOOT_STATE_UPDATE_TRIAL);
}

int BootState_IsConfirmed(const BootStateRecord_t *record)
{
    return BootState_IsValidRecord(record) &&
           (record->state == BOOT_STATE_CONFIRMED);
}

int BootState_IsAddressInSram(uint32_t address)
{
    return ((address & 0x2FFE0000UL) == 0x20000000UL);
}

int BootState_IsAddressInFlash(uint32_t address)
{
    return (address >= FLASH_PHYSICAL_BASE) &&
           (address < (FLASH_PHYSICAL_BASE + FLASH_LAYOUT_TOTAL_SIZE));
}

int BootState_IsValidImageVectorTable(uint32_t image_addr, uint32_t slot)
{
    uint32_t slot_addr = BootState_GetAddressForSlot(slot);
    uint32_t slot_size = BootState_GetSizeForSlot(slot);

    if ((slot_addr == 0U) || (slot_size == 0U) || (image_addr != slot_addr))
    {
        return 0;
    }

    uint32_t initial_sp = *(const volatile uint32_t *)image_addr;
    uint32_t reset_pc   = *(const volatile uint32_t *)(image_addr + 4U);
    uint32_t reset_addr = reset_pc & ~1UL;

    if (!BootState_IsAddressInSram(initial_sp))
    {
        return 0;
    }

    if ((reset_pc & 0x1U) == 0U)
    {
        return 0;
    }

    if ((reset_addr < slot_addr) || (reset_addr >= (slot_addr + slot_size)))
    {
        return 0;
    }

    return BootState_IsAddressInFlash(reset_addr);
}

BootStateRecord_t BootState_MakeUpdatePendingRecord(uint32_t current_slot,
                                                    uint32_t update_slot,
                                                    uint32_t update_version,
                                                    uint32_t update_size,
                                                    uint32_t update_crc)
{
    BootStateRecord_t record = {
        .magic = BOOT_STATE_RECORD_MAGIC,
        .version = BOOT_STATE_RECORD_VERSION,
        .state = BOOT_STATE_UPDATE_PENDING,
        .current_slot = current_slot,
        .update_slot = update_slot,
        .rollback_slot = current_slot,
        .update_version = update_version,
        .update_size = update_size,
        .update_crc = update_crc,
        .boot_attempt_count = 0U,
        .reserved0 = 0U,
        .reserved1 = 0U
    };

    return record;
}

BootStateRecord_t BootState_MakeUpdateTrialRecord(const BootStateRecord_t *record)
{
    BootStateRecord_t trial_record = *record;

    trial_record.state = BOOT_STATE_UPDATE_TRIAL;
    trial_record.boot_attempt_count = record->boot_attempt_count + 1U;

    return trial_record;
}

BootStateRecord_t BootState_MakeConfirmedRecord(uint32_t current_slot,
                                                uint32_t rollback_slot,
                                                uint32_t firmware_version)
{
    BootStateRecord_t record = {
        .magic = BOOT_STATE_RECORD_MAGIC,
        .version = BOOT_STATE_RECORD_VERSION,
        .state = BOOT_STATE_CONFIRMED,
        .current_slot = current_slot,
        .update_slot = BOOT_SLOT_NONE,
        .rollback_slot = rollback_slot,
        .update_version = firmware_version,
        .update_size = 0U,
        .update_crc = 0U,
        .boot_attempt_count = 0U,
        .reserved0 = 0U,
        .reserved1 = 0U
    };

    return record;
}

static int BootState_EraseStateArea(void)
{
    FLASH_EraseInitTypeDef erase;
    uint32_t page_error = 0U;
    HAL_StatusTypeDef status;

    erase.TypeErase = FLASH_TYPEERASE_PAGES;
    erase.Banks = FLASH_BANK_1;
    erase.Page = (ADDR_BOOT_STATE - FLASH_PHYSICAL_BASE) / FLASH_LAYOUT_PAGE_SIZE;
    erase.NbPages = SIZE_BOOT_STATE / FLASH_LAYOUT_PAGE_SIZE;

    HAL_FLASH_Unlock();
    status = HAL_FLASHEx_Erase(&erase, &page_error);
    HAL_FLASH_Lock();

    return (status == HAL_OK);
}

static int BootState_ProgramRecord(const BootStateRecord_t *record)
{
    HAL_StatusTypeDef status = HAL_OK;
    uint8_t buffer[sizeof(BootStateRecord_t)];

    memcpy(buffer, record, sizeof(buffer));

    HAL_FLASH_Unlock();

    for (uint32_t offset = 0U; offset < sizeof(buffer); offset += 16U)
    {
        status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_QUADWORD,
                                   BOOT_STATE_ADDR + offset,
                                   (uint32_t)&buffer[offset]);

        if (status != HAL_OK)
        {
            break;
        }
    }

    HAL_FLASH_Lock();

    return (status == HAL_OK);
}

int BootState_WriteRecord(const BootStateRecord_t *record)
{
    if (!BootState_IsValidRecord(record))
    {
        return 0;
    }

    if (!BootState_EraseStateArea())
    {
        return 0;
    }

    return BootState_ProgramRecord(record);
}
