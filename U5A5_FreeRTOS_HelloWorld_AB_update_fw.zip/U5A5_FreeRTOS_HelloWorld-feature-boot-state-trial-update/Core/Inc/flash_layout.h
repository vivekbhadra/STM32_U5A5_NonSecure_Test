#ifndef FLASH_LAYOUT_H
#define FLASH_LAYOUT_H

#include <stdint.h>

/* STM32U5 Flash Physical Characteristics */
#define FLASH_PHYSICAL_BASE             0x08000000U
#define FLASH_LAYOUT_TOTAL_SIZE         (2U * 1024U * 1024U)
#define FLASH_LAYOUT_BANK_SIZE          (1024U * 1024U)       /* 1 MB per Bank */
#define FLASH_LAYOUT_PAGE_SIZE          8192U                 /* 8 KB per Page */

/* Physical Partition Base Addresses */
#define ADDR_BOOTLOADER                 0x08000000U
#define ADDR_BOOT_STATE                 0x08020000U
#define ADDR_FLASH_SLOT_A               0x08040000U
#define ADDR_FLASH_SLOT_B               0x08100000U
#define ADDR_SPARE                      0x081C0000U

/* Backwards-compatible names during migration. */
#define ADDR_FLASH_ACTIVE               ADDR_FLASH_SLOT_A
#define ADDR_FLASH_DFU                  ADDR_FLASH_SLOT_B

/* Partition Sizes */
#define SIZE_BOOTLOADER                 (128U * 1024U)        /* 128 KB */
#define SIZE_BOOT_STATE                 (128U * 1024U)        /* 128 KB */
#define SIZE_FLASH_SLOT_A               (768U * 1024U)        /* 768 KB */
#define SIZE_FLASH_SLOT_B               (768U * 1024U)        /* 768 KB */
#define SIZE_SPARE                      (256U * 1024U)        /* 256 KB */

/* Backwards-compatible names during migration. */
#define SIZE_FLASH_ACTIVE               SIZE_FLASH_SLOT_A
#define SIZE_FLASH_DFU                  SIZE_FLASH_SLOT_B

/* Partition Page Allocations */
#define PAGES_BOOTLOADER                (SIZE_BOOTLOADER / FLASH_LAYOUT_PAGE_SIZE)
#define PAGES_BOOT_STATE                (SIZE_BOOT_STATE / FLASH_LAYOUT_PAGE_SIZE)
#define PAGES_FLASH_SLOT_A              (SIZE_FLASH_SLOT_A / FLASH_LAYOUT_PAGE_SIZE)
#define PAGES_FLASH_SLOT_B              (SIZE_FLASH_SLOT_B / FLASH_LAYOUT_PAGE_SIZE)

#endif /* FLASH_LAYOUT_H */
