#ifndef FLASH_DRIVER_H
#define FLASH_DRIVER_H

#include "stm32u5xx_hal.h"
#include "flash_layout.h"

#define DFU_PARTITION_SIZE     SIZE_FLASH_SLOT_B

/* Legacy magic status flags retained only for temporary compatibility. */
extern const uint8_t MAGIC_BOOT[16];
extern const uint8_t MAGIC_SWAP[16];
extern const uint8_t MAGIC_REVERT[16];

HAL_StatusTypeDef App_Flash_Erase(uint32_t start_address, uint32_t size);
HAL_StatusTypeDef App_Flash_Write(uint32_t start_address, const uint8_t *data, uint32_t length);
void Mark_Firmware_As_Valid(void);

#endif /* FLASH_DRIVER_H */
