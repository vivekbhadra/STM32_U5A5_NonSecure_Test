#ifndef BOOT_STATE_H
#define BOOT_STATE_H

#include <stdint.h>
#include "flash_layout.h"

/*
 * A/B Update FW boot-state metadata.
 *
 * Slot A: 0x08040000
 * Slot B: 0x08100000
 *
 * Current FW  = currently trusted and confirmed firmware.
 * Update FW   = newly received firmware being trial-booted from the inactive slot.
 * Rollback FW = previous confirmed firmware retained as fallback.
 */

#define BOOT_STATE_RECORD_MAGIC          0x42535455UL  /* 'BSTU' */
#define BOOT_STATE_RECORD_VERSION        2UL
#define BOOT_STATE_MAX_TRIAL_ATTEMPTS    1UL

#define BOOT_STATE_ADDR                  ADDR_BOOT_STATE

#define BOOT_SLOT_NONE 0U
#define BOOT_SLOT_A    1U
#define BOOT_SLOT_B    2U

typedef uint32_t BootSlot_t;

typedef enum
{
    BOOT_STATE_EMPTY            = 0xFFFFFFFFUL,
    BOOT_STATE_CONFIRMED        = 0x11111111UL,
    BOOT_STATE_UPDATE_PENDING   = 0x22222222UL,
    BOOT_STATE_UPDATE_TRIAL     = 0x33333333UL,
    BOOT_STATE_ROLLBACK         = 0x44444444UL
} BootStateValue_t;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t state;
    uint32_t current_slot;

    uint32_t update_slot;
    uint32_t rollback_slot;
    uint32_t update_version;
    uint32_t update_size;

    uint32_t update_crc;
    uint32_t boot_attempt_count;
    uint32_t reserved0;
    uint32_t reserved1;
} BootStateRecord_t;

_Static_assert((sizeof(BootStateRecord_t) % 16U) == 0U,
               "BootStateRecord_t must remain 16-byte aligned in size");

const BootStateRecord_t *BootState_GetRecord(void);

int BootState_IsValidSlot(uint32_t slot);
uint32_t BootState_GetAddressForSlot(uint32_t slot);
uint32_t BootState_GetSizeForSlot(uint32_t slot);
uint32_t BootState_GetInactiveSlot(uint32_t current_slot);

int BootState_IsValidRecord(const BootStateRecord_t *record);
int BootState_IsUpdatePending(const BootStateRecord_t *record);
int BootState_IsUpdateTrial(const BootStateRecord_t *record);
int BootState_IsConfirmed(const BootStateRecord_t *record);
int BootState_IsUpdateImageSizeValid(uint32_t slot, uint32_t image_size);

int BootState_IsAddressInSram(uint32_t address);
int BootState_IsAddressInFlash(uint32_t address);
int BootState_IsValidImageVectorTable(uint32_t image_addr, uint32_t slot);

BootStateRecord_t BootState_MakeUpdatePendingRecord(uint32_t current_slot,
                                                    uint32_t update_slot,
                                                    uint32_t update_version,
                                                    uint32_t update_size,
                                                    uint32_t update_crc);

BootStateRecord_t BootState_MakeUpdateTrialRecord(const BootStateRecord_t *record);

BootStateRecord_t BootState_MakeConfirmedRecord(uint32_t current_slot,
                                                uint32_t rollback_slot,
                                                uint32_t firmware_version);

int BootState_WriteRecord(const BootStateRecord_t *record);

#endif /* BOOT_STATE_H */
